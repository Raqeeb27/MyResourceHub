# Advanced Script Analysis with chatGPT

Use three scripts with increasingly complex obfuscation to see how chatGPT can aid in the malware analysis process.
